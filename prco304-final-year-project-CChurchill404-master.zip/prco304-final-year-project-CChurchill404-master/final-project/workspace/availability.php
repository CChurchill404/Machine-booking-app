<?php
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'Machines');

  $output = '';

  if(isset($_POST['search'])) {
    $search = $_POST['search'];
 

    $query = mysqli_query($con, "SELECT * FROM machines WHERE Item LIKE '%$search%' OR Size LIKE '%$search%' OR Booked LIKE '%$search%' OR Area LIKE '%$search%' OR Postcode LIKE '%$search%' OR ContractNumber LIKE '%$search%' OR SiteContact LIKE '%$search%'");
    $count = mysqli_num_rows($query);
    
    if($count == 0){
      $output = "There was no search results!";

    }else{

      while ($row = mysqli_fetch_array($query)) {

        $ID = $row ['ID'];
        $Item = $row ['Item'];
        $Size = $row ['Size'];
        $Booked = $row ['Booked'];
        $Area = $row ['Area'];
        $Postcode = $row ['Postcode'];
        $ContractNumber = $row ['ContractNumber'];
        $SiteContact = $row ['SiteContact'];
        $Condition = $row ['Condition'];
        $Orderdate = $row ['Orderdate'];
        $Returndate = $row['Returndate'];
        
        echo "'<h1><div>Sorry, but the availability for'.$Item.'was booked out on the'.$Orderdate.'and doesn't return until.$Returndate.'</div></h1>";

      }
    }
  }

  ?>
</div>
</body>
</html>