<html>
<head>
<link rel="stylesheet" type="text/css" href="styles.css">    
<link rel="stylesheet" type="text/css" href="styles1.css">
<title>Searched Result</title>
<meta name="viewport" content="width=device-width, initial-scale= 0.9">
</head>
<body>
<div class = "div1">

            <form method="get" action="dashboard.php">
            <button class="button4"><h1>Back</h1></button>
            </form>

<?php
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'Machines');

  $output = '';

  if(isset($_POST['search'])) {
    $search = $_POST['search'];
 

    $query = mysqli_query($con, "SELECT * FROM machines WHERE Item LIKE '%$search%' OR Size LIKE '%$search%' OR Booked LIKE '%$search%' OR Area LIKE '%$search%' OR Postcode LIKE '%$search%' OR ContractNumber LIKE '%$search%' OR SiteContact LIKE '%$search%'");
    $count = mysqli_num_rows($query);
    
    if($count == 0){
      $output = "There was no search results!";

    }else{

      while ($row = mysqli_fetch_array($query)) {

        $ID = $row ['ID'];
        $Item = $row ['Item'];
        $Size = $row ['Size'];
        $Booked = $row ['Booked'];
        $Area = $row ['Area'];
        $Postcode = $row ['Postcode'];
        $ContractNumber = $row ['ContractNumber'];
        $SiteContact = $row ['SiteContact'];
        $Condition = $row ['Condition'];
        $Orderdate = $row ['Orderdate'];
        $Returndate = $row['Returndate'];
        
        echo "'<h1><div>'.$ID''.$Item.''.$Size.''.$Booked.''.$Area.''.$Postcode.''.$ContractNumber.''.$SiteContact.''.$Condition.''.$Orderdate.''.$Returndate.'</div></h1>";

      }
    }
  }

  ?>
</div>
</body>
</html>
