<!DOCTYPE HTML>
<html>
<head>
<title>Login Page</title>
<link rel="stylesheet" type="text/css" href="styles.css">
 <link rel="stylesheet" type="text/css" href="styles1.css">
<meta name="viewport" content="width=device-width, initial-scale=0.9">
</head>
<body>
<div class = "div1">
    <center><img src="https://www.eque2.co.uk/wp-content/uploads/2017/05/gilpin-demolition-group.jpg"></center>
        <form action="function.php" method="POST">
        <p>
            <label><h1>Username</h1></label>
          <center><input type="text" id="user" name="user" /></center>
        </p>
        <p>
            <center><label><h1>Password</h1></label></center>
            <center><input type="password" id="pass" name="pass" /><center>
        </p>
        <p>
            <center><input type="submit" id="btn" value="Login" name="submit" /></center>
        </p>
    </form>
</div>
</body>
</html>