<?php 
    
    $con = mysqli_connect('localhost','root','');
    mysqli_select_db($con,'Machines');
    $value = $_POST['pselect'];
    $bbdate = $_POST['bbdate'];
    $Returndate=$_POST['Returndate'];

if ($query = mysqli_query($con, "UPDATE machines SET Booked ='$_POST[Yes]', 
    Area='$_POST[farea]',
    Postcode='$_POST[fpostcode]',
    ContractNumber='$_POST[fcontractnumber]',
    SiteContact='$_POST[fsitecontact]',
    Orderdate='$_POST[obdate]',
    Returndate='$_POST[bbdate]'
    WHERE Item = '$_POST[pselect]' AND '$_POST[bbdate]' >= Returndate"));
    if($bbdate > $Returndate){
    header("refresh:1; url=tyorder.php");
    }
    elseif($bbdate < $Returndate){
    header("refresh:1; url=dashboard.php");
}
?>    