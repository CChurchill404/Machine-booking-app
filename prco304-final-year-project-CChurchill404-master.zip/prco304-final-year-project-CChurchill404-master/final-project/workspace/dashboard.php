<?
     $con = mysqli_connect('localhost','root','');
     mysqli_select_db($con,'Machines');
     
     if(isset($_POST['search'])) {
         $searchq = $_POST['search'];
         $searchq = preg_replace("#[^0-9a-z]#i","",$searchq);
         
         $query = mysql_query() or die("could not search");
     }
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="styles.css">
<link rel="stylesheet" type="text/css" href="styles1.css">
<title>Office Hub</title>
<meta name="viewport" content="width=device-width, initial-scale= 0.1">
</head>
<body>
<div class = "div1">
             <center><img src="https://www.eque2.co.uk/wp-content/uploads/2017/05/gilpin-demolition-group.jpg"></center>
            <form method="get" action="update.php">
            <center><button class="button7"><h1>Recent Orders / Update Machinery</h1></button></center>
            </form>    
            
            <form method="get" action="excavators.php">
            <center><button class="button8"><h1>Excavators / Recent Logs</h1></button></center>
            </form>
            
            <form method="get" action="misc.php">
            <center><button class="button9"><h1>Miscellaneous Machinery / Recent Logs</h1></button></center>
            </form>
            
            <form method ="get" action="basepage.php">
            <center><button class="button3"><h1>Back</h1></button></center>   
            </form>
           
</div>          
<div style = "margin-left: auto; margin-right: auto;">
            <form method="POST" action="0search.php">
            <center><input type="text" name="search" placeholder="Search for machines" style = "width: 250px; height: 6%; font-size: 25px;"></center>
            <center><input type="submit" style = "width: 250px; height: 6%; font-size: 25px;" value="Search"/></center
            </form>
</div>
</body>
</html>