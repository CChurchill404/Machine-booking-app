<html>
<head>
<link rel="stylesheet" type="text/css" href="styles.css">    
<link rel="stylesheet" type="text/css" href="styles1.css">
<title>Thirty-Five Tonne</title>
<meta name="viewport" content="width=device-width, initial-scale= 0.9">
</head>
<body>
<div class = "div1">

            <form method="get" action="excavators.php">
            <button class="button4"><h1>Back</h1></button></button>
            </form>    


        <?php

            $con = mysqli_connect('localhost','root','');
            mysqli_select_db($con,'Machines');
                
            $sql = "SELECT * FROM machines WHERE Size='35'";
                
            //Execute Query
            $records = mysqli_query($con,$sql);
            
            ?>
             <h1><table border = 1 style="color: black; margin-left: auto; margin-right: auto;">
                <tr>
                    <th>Item</th>
                    <th>Size</th>
                    <th>Booked</th>
                    <th>Area</th>
                    <th>Postcode</th>
                    <th>Contract Number</th>
                    <th>Site Contact</th>
                    <th>Serial Number</th>
                </tr>
                <?php
                while($row = mysqli_fetch_array($records))
                {
                    echo "<td>'".$row['Item']."'</td>";
                    echo "<td>'".$row['Size']."'</td>";
                    echo "<td>'".$row['Booked']."'</td>";
                    echo "<td>'".$row['Area']."'</td>";
                    echo "<td>'".$row['Postcode']."'</td>";
                    echo "<td>'".$row['ContractNumber']."'</td>";
                    echo "<td>'".$row['SiteContact']."'</td>";
                    echo "<td>'".$row['SerialNumber']."'</td>";
                    echo "</form></tr>";
                    
                }
                ?>
        
</table></h1>
</div>
</body>
</html>