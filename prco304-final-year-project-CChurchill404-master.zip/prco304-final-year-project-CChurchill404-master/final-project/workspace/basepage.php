<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=0.1">
        <link rel="stylesheet" type="text/css" href="styles.css">
        <link rel="stylesheet" type="text/css" href="styles1.css">
        <title>
            Select Sector
        </title>
    </head>
    <body>
        <div class="div1">
                <center><img src="https://www.eque2.co.uk/wp-content/uploads/2017/05/gilpin-demolition-group.jpg"></center>
                <a href="1site.php"><h2>Machine Booking</h2><img class = "img1" src="https://image.flaticon.com/icons/png/512/116/116433.png"></a>
                <a href="dashboard.php"><h3>Fleet Management</h3><img class = "img2" src="http://icons.iconarchive.com/icons/iconsmind/outline/256/Office-icon.png"></a>
            </form>
        </div>
    </body>
</html>