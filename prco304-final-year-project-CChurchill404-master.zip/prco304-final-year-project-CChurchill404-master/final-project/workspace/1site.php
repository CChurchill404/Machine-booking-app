<html>
    <head>
        <meta name="viewport" content="width=device-height, initial-scale=0.001">
        <title>Site Manager Hub</title>
        <link rel="stylesheet" type="text/css" href="styles.css">
         <link rel="stylesheet" type="text/css" href="styles1.css">
    </head>
    <body>
        <div class = "div1">
            <center><img src="https://www.eque2.co.uk/wp-content/uploads/2017/05/gilpin-demolition-group.jpg"></center>
            <form method="get" action="book.php">
            <center><button class="button1"><h1>Book Machine</h1></button></center>
            </form>    
            <form method="get" action="return.php">
            <center><button class="button2"><h1>Amend Orders / Check Availability</h1></button></center>
            </form> 
            <form method ="get" action="basepage.php">
            <center><button class="button3"><h1>Back</h1></button></center>  
            </form>
            
        </div>
    </body>
</html>