<?php 
    
    $con = mysqli_connect('localhost','root','');
    mysqli_select_db($con,'Machines');
    $value = $_POST['pselect'];
 

    $sql = "UPDATE machines SET Booked = 'Yes', 
    Booked='$_POST[No]',
    Area='$_POST[farea]',
    Postcode='$_POST[fpostcode]',
    ContractNumber='$_POST[fcontractnumber]',
    SiteContact='$_POST[fsitecontact]',
    Orderdate='$_POST[obdate]',
    Returndate='$_POST[bbdate]'
    WHERE Item = '$_POST[pselect]'
    ";
    
    //Execute Query
    if(mysqli_query($con,$sql))
    header("refresh:1; url=tyreturn.php");
    else
    echo "nope";
    ?>