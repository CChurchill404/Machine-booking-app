<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=0.1">
        <link rel="stylesheet" type="text/css" href="styles.css">
        <link rel="stylesheet" type="text/css" href="styles1.css">
        <title>
            Thank you
        </title>
    </head>
    <body>
        <div class="div1">
                <h1>Thank you for returning the machine please return home.</h1>
                <form method="get" action="1site.php">
                <center><button class="button11"><h1>Home</h1></button></center>
        </form>  
        </div>
    </body>
</html>