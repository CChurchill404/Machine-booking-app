<html>
<head>
<link rel="stylesheet" type="text/css" href="styles.css">    
<link rel="stylesheet" type="text/css" href="styles1.css">
<title>Book</title>
<meta name="viewport" content="width=device-width, initial-scale= 0.1">
</head>
<body>
<div class = "div1">
            <form method="get" action="1site.php">
            <button class="button4"><h1>Back</h1></button>
            </form>    


<?php
  $con = mysqli_connect('localhost','root','');
  mysqli_select_db($con,'Machines');
  
   $con = mysqli_connect('localhost','root','');
            mysqli_select_db($con,'Machines');
                
            $sql = "SELECT Item FROM machines WHERE Booked='Yes'";
                
            //Execute Query
            $records = mysqli_query($con,$sql);
?>

<form name="pmachine" action="return8.php" method="POST">
<center><select name="pselect" class="select3"></center>
<option>Select the machine you would like to Extend?</option>   
<?php
    $res=mysqli_query($con, "SELECT Item FROM machines WHERE Booked='Yes'");
    while($row=mysqli_fetch_array($res))
{
    $item = $row['Item'];
    echo"<option value='$item'>$item</option>";
}
?>
</select>
<h4>How long would you like to extend this machines booking state?</h4>
<center><input type="date" name="ebbdate"></center>
<center><input type = submit class="button6"></center>
</form>

<form>
<?php
  $con = mysqli_connect('localhost','root','');
  mysqli_select_db($con,'Machines');
  
   $con = mysqli_connect('localhost','root','');
            mysqli_select_db($con,'Machines');
                
            $sql = "SELECT Item FROM machines WHERE Booked='Yes'";
                
            //Execute Query
            $records = mysqli_query($con,$sql);
?>
</form>

<form name="pmachine" action="return9.php" method="POST">
<center><select name="pselect" class="select3"></center>
<option>Select the machine you would like to return?</option>   
<?php
    $res=mysqli_query($con, "SELECT Item FROM machines WHERE Booked='Yes'");
    while($row=mysqli_fetch_array($res))
{
    $item = $row['Item'];
    echo"<option value='$item'>$item</option>";
}
?>
</select
<center><button name="No" type="submit" value="No" class="button5">Submit</button></center>
</form
<form></form>


<?php
  $con = mysqli_connect('localhost','root','');
  mysqli_select_db($con,'Machines');
  
    $con = mysqli_connect('localhost','root','');
    mysqli_select_db($con,'Machines');
            $sql = "SELECT Item FROM machines WHERE Booked='Yes'";
            //Execute Query
            $records = mysqli_query($con,$sql);
?>
</form>
<form name="pmachine" method="POST">
<center><select name="pselect" class="select2"></center>
<option>Select the machine you would like to check the availability of?</option>   
<?php
    $res=mysqli_query($con, "SELECT Item FROM machines");
    while($row=mysqli_fetch_array($res))
{
    $item = $row['Item'];
    echo"<option value='$item'>$item</option>";
}
?>
</select>
<center><button name="search" type="submit" value="No" class="button5" onclick="myFunction">Submit</button></center>
<?php 
    
    $con = mysqli_connect('localhost','root','');
    mysqli_select_db($con,'Machines');
    $value = $_POST['pselect'];


    $query = mysqli_query($con, "SELECT * FROM machines WHERE Item = '$_POST[pselect]'");
    $count = mysqli_num_rows($query);
    if($count == 0){
      $output = "There was no search results!";

    }else{

      while ($row = mysqli_fetch_array($query)) {
          $Returndate = $row['Returndate'];
            echo '<script language="javascript">';
            echo 'alert("The machine '.$value.' is available from '.$Returndate.'")';
            echo '</script>';
      }
    }
 ?>
</form
</div>
</body>
</html>