<html>
<head>
<link rel="stylesheet" type="text/css" href="styles.css">    
<link rel="stylesheet" type="text/css" href="styles1.css">
<title>Excavators</title>
<meta name="viewport" content="width=device-width, initial-scale= 0.9">
</head>
<body>
<div class = "div1">
            <form method="get" action="dashboard.php">
            <button class="button4"><h1>Back</h1></button>
            </form>

            <form method="get" action="8excavators.php">
            <center><button class="button12"><h1>Recent Logs for Eight Tonne Excavators</h1></button></center>
            </form>

            <form method="get" action="21excavators.php">
            <center><button class="button13"><h1>Recent Logs for Twenty-One Tonne Excavators</h1></button></center>
            </form>
 
            <form method="get" action="35excavators.php">
            <center><button class="button14"><h1>Recent Logs for Thirty-Five Tonne Excavators</h1></button></center>
            </form>

            <form method="get" action="65excavators.php">
            <center><button class="button15"><h1>Recent Logs for Sixty-Five Tonne Excavators</h1></button></center>
            </form>

</div>
</body>
</html>