<html>
<head>
<title>Machine Booking</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<link rel="stylesheet" type="text/css" href="styles1.css">
<meta name="viewport" content="width=device-width, initial-scale= 1">
</head>
<body>
<div class = "div1">
    <form method="get" action="1site.php">
    <button class="button4"><h1>Back</h1></button>
    </form>    

<?php
    $con = mysqli_connect('localhost','root','');
    mysqli_select_db($con,'Machines');
  
    $con = mysqli_connect('localhost','root','');
            mysqli_select_db($con,'Machines');
                
            $sql = "SELECT Item FROM machines WHERE Booked='8'";
                
            //Execute Query
            $records = mysqli_query($con,$sql);
?>
<form name="pmachine" action="book8.php" method="POST">
<center><select name="pselect" select class = "select1"></center>
<option><h1>Select the machine you would like to book</h1></option>   
<?php
    $res=mysqli_query($con, "SELECT Item FROM machines WHERE Booked='No'");
    while($row=mysqli_fetch_array($res))
{
    $item = $row['Item'];
    echo"<option value='$item'>$item</option>";
}
?>
</select>
<center><h4>Select an order date</h4></center>

<center><h1><input type="date" name="obdate" value="obdate"></h1></center>

<center><h4>Select a return date</h4></center>

<center><input type="date" name="bbdate" value="bbdate"></center>

<center><input type="text" name="farea" placeholder="Insert Area" class="input1"></center>

<center><input type="text" name="fpostcode" placeholder="Insert Postcode" class="input2"></center>

<center><input type="text" name="fcontractnumber" placeholder="Insert Contract Number" class="input3"></center>

<center><input type="text" name="fsitecontact" placeholder="Insert Site Contact" class="input4"></center>

<input type=hidden name=id value="<?php echo htmlspecialchars($ID); ?>">

<center><h1>Would you like to complete this order?</h1></center>

<center><input type="submit" name="Yes" value="Yes" class="button5" ></center>
</form>
</div>
</body>
</html>
