<?php 
    
    $con = mysqli_connect('localhost','root','');
    mysqli_select_db($con,'Machines');
    $value = $_POST['pselect'];
    
    $sql = "UPDATE machines SET Booked = 'Yes', 
    returndate='$_POST[ebbdate]'
    WHERE Item = '$_POST[pselect]'
    ";
    
    //Execute Query
    if(mysqli_query($con,$sql))
    header("refresh:1; url=tyupdate.php");
    else
    echo "nope";
    ?>