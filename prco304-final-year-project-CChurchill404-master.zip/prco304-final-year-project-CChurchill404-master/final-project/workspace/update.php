<html>
<head>
<link rel="stylesheet" type="text/css" href="styles.css">
<link rel="stylesheet" type="text/css" href="styles1.css">
<title>Update</title>
<meta name="viewport" content="width=device-width, initial-scale= 0.1">
</head>
<body>
<div class = "div2">

        <form method="get" action="dashboard.php">
        <button class="button4"><h1>Back</h1></button>
        </form>

<?php 
    
    $con = mysqli_connect('localhost','root','');
    mysqli_select_db($con,'Machines');
    
    $sql = "SELECT * FROM machines";
    
    //Execute Query
    $records = mysqli_query($con,$sql);
    
?>
<table align="center" table style="font-color: black;">
    <h1><tr>
        <th>Item</th>
        <th>Size</th>
        <th>Booked</th>
        <th>Area</th>
        <th>Postcode</th>
        <th>Contract Number</th>
        <th>Site Contact</th>
        <th>Serial Number</th>
    </tr></h1>
    <?php
    while($row = mysqli_fetch_array($records))
    {
        echo "<tr><form action=update8.php method=post>";
        echo "<td><input type=text name=pitem value='".$row['Item']."'</td>";
        echo "<td><input type=text name=psize value='".$row['Size']."'</td>";
        echo "<td><input type=text name=pbooked value='".$row['Booked']."'</td>";
        echo "<td><input type=text name=parea value='".$row['Area']."'</td>";
        echo "<td><input type=text name=ppostcode value='".$row['Postcode']."'</td>";
        echo "<td><input type=text name=pcontractnumber value='".$row['ContractNumber']."'</td>";
        echo "<td><input type=text name=psitecontact value='".$row['SiteContact']."'</td>";
        echo "<td><input type=text name=pserial value='".$row['SerialNumber']."'</td>";
        echo "<input type=hidden name=id value='".$row['ID']."'>";
        echo "<td><input type =submit>";
        echo "</form></tr>";
        
    }
    ?>
</table>
</div>
</body>
</html>
