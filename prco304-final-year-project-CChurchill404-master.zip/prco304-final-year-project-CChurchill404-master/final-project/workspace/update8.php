<?php 
    
    $con = mysqli_connect('localhost','root','');
    mysqli_select_db($con,'Machines');
    
        $sql = "UPDATE machines SET Item='$_POST[pitem]', 
        Size='$_POST[psize]',
        Booked='$_POST[pbooked]',
        Area='$_POST[parea]',
        Postcode='$_POST[ppostcode]',
        ContractNumber='$_POST[pcontractnumber]',
        SiteContact='$_POST[psitecontact]'
        WHERE ID='$_POST[id]'
        ";
    
    //Execute Query
    if(mysqli_query($con,$sql))
    header("refresh:1; url=update.php");
    else
    echo "nope";
    ?>